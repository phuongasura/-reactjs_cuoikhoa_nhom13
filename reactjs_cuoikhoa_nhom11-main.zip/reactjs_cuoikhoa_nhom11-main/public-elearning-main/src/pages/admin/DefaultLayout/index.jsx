import React, { Component } from 'react';

export default class DefaultAdminLayout extends Component {
  render() {
    return <div>This is Default admin layout</div>;
  }
}
