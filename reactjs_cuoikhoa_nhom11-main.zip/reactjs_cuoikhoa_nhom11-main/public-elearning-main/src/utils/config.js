export const api = 'https://elearning0706.cybersoft.edu.vn/api';
